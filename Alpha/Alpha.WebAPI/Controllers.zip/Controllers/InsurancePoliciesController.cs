using Alpha.Common;
using Alpha.Model;
using Alpha.Service.Common;
using Microsoft.AspNetCore.Mvc;

namespace Alpha.WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InsurancePoliciesController : ControllerBase
    {
        private readonly IInsurancePolicyService _insurancePolicyService;

        public InsurancePoliciesController(IInsurancePolicyService insurancePolicyService)
        {
            _insurancePolicyService = insurancePolicyService;
        }

        [HttpGet]
        public async Task<IActionResult> GetPolicies(
            [FromQuery] string? search = "",
            [FromQuery] string? status = "",
            [FromQuery] string? insuranceCompany = "",
            [FromQuery] string? insuranceType = "",
            [FromQuery] string? location = "",
            [FromQuery] string? partner = "",
            [FromQuery] decimal priceFrom = 0,
            [FromQuery] decimal priceTo = decimal.MaxValue,
            [FromQuery] DateTime? dateFrom = null,
            [FromQuery] DateTime? dateTo = null,
            [FromQuery] int year = 2026,
            [FromQuery] bool isAsc = false,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10)
        {
            var filter = new InsuranceFiltering(
                year: year.ToString(),
                isAsc: isAsc,
                search: search ?? string.Empty,
                priceFrom: priceFrom,
                priceTo: priceTo,
                dateFrom: dateFrom ?? DateTime.Today,
                dateTo: dateTo ?? DateTime.Today,
                status: status ?? string.Empty,
                insuranceCompany: insuranceCompany ?? string.Empty,
                insuranceType: insuranceType ?? string.Empty,
                location: location ?? string.Empty,
                partner: partner ?? string.Empty
            );

            var paging = new Paging
            {
                PageNumber = pageNumber,
                PageSize = pageSize
            };

            var policies = await _insurancePolicyService.GetInsurancePolicyListAsync(filter, paging, false);
            var totalCount = await _insurancePolicyService.GetTotalPolicyCountAsync(filter);

            var result = new PagedResponse<InsurancePolicyTableDto>
            {
                Items = policies.Select(x => new InsurancePolicyTableDto
                {
                    Id = x.PolicyNumber,
                    Status = MapStatus(x.Status),
                    Ugovaratelj = x.ClientName,
                    DatumProduzenja = x.StartingDate.ToString("dd.MM.yyyy."),
                    OsiguravajucaKuca = x.InsuranceCompany,
                    VrstaOsiguranja = x.InsuranceType,
                    Premija = $"{x.Price:0.00} €",
                    ProdajnoMjesto = x.Location,
                    PolicyNumber = x.PolicyNumber,
                    StartingDate = x.StartingDate,
                    Price = x.Price
                }).ToList(),
                PageNumber = pageNumber,
                PageSize = pageSize,
                TotalCount = totalCount,
                TotalPages = (int)Math.Ceiling((double)totalCount / pageSize)
            };

            return Ok(result);
        }

        [HttpGet("tab-counts")]
        public async Task<IActionResult> GetTabCounts([FromQuery] int year = 2026)
        {
            async Task<int> GetCountForStatus(string status)
            {
                var filter = new InsuranceFiltering(
                    year: year.ToString(),
                    isAsc: false,
                    search: string.Empty,
                    priceFrom: 0,
                    priceTo: decimal.MaxValue,
                    dateFrom: DateTime.Today,
                    dateTo: DateTime.Today,
                    status: status,
                    insuranceCompany: string.Empty,
                    insuranceType: string.Empty,
                    location: string.Empty,
                    partner: string.Empty
                );

                return await _insurancePolicyService.GetTotalPolicyCountAsync(filter);
            }

            var allCount = await GetCountForStatus(string.Empty);
            var activeCount = await GetCountForStatus("ActiveStatus");
            var inactiveCount = await GetCountForStatus("InactiveStatus");
            var twoWeekCount = await GetCountForStatus("TwoWeekStatus");
            var oneWeekCount = await GetCountForStatus("OneWeekStatus");

            return Ok(new
            {
                svi = allCount,
                aktivni = activeCount,
                neaktivni = inactiveCount,
                dvaTjedna = twoWeekCount,
                tjedan = oneWeekCount
            });
        }

        private static string MapStatus(string status)
        {
            return status switch
            {
                "Renewed" => "Produženo",
                "Active" => "Aktivno",
                "Inactive" => "Neaktivno",
                "Two Weeks Active" => "2 tjedna prije isteka",
                "One Week Active" => "Tjedan prije isteka",
                _ => status
            };
        }
    }

    public class InsurancePolicyTableDto
    {
        public string Id { get; set; } = string.Empty;
        public string PolicyNumber { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public string Ugovaratelj { get; set; } = string.Empty;
        public string DatumProduzenja { get; set; } = string.Empty;
        public string OsiguravajucaKuca { get; set; } = string.Empty;
        public string VrstaOsiguranja { get; set; } = string.Empty;
        public string Premija { get; set; } = string.Empty;
        public string ProdajnoMjesto { get; set; } = string.Empty;
        public DateTime StartingDate { get; set; }
        public decimal Price { get; set; }
    }

    public class PagedResponse<T>
    {
        public List<T> Items { get; set; } = new();
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public int TotalCount { get; set; }
        public int TotalPages { get; set; }
    }
}