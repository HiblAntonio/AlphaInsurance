using Alpha.Common;
using Alpha.Model;
using Alpha.Service.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Alpha.WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AgentController : ControllerBase
    {
        private readonly IAgentService _agentService;

       public AgentController(IAgentService agentService)
        {
            _agentService = agentService;
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginInfo userDetails)
        {
            if (userDetails == null ||
                string.IsNullOrWhiteSpace(userDetails.IdMail) ||
                string.IsNullOrWhiteSpace(userDetails.Password))
            {
                return BadRequest(new LoginResponse
                {
                    Success = false,
                    Message = "Identifikacijski broj i lozinka su obavezni."
                });
            }

            var loginValid = await _agentService.CheckLoginInfoAsync(userDetails);

            if (!loginValid)
            {
                return Unauthorized(new LoginResponse
                {
                    Success = false,
                    Message = "Pogrešan identifikacijski broj ili lozinka."
                });
            }

            var agent = await _agentService.GetAgentByIdAsync(userDetails.IdMail);

            if (agent == null)
            {
                return Unauthorized(new LoginResponse
                {
                    Success = false,
                    Message = "Korisnik nije pronađen."
                });
            }

            var token = string.Empty;

            return Ok(new LoginResponse
            {
                Success = true,
                Message = "Prijava uspješna.",
                Token = token,
                Agent = agent
            });
        }

        [Authorize]
        [HttpGet("me")]
        public async Task<IActionResult> Me()
        {
            var identificationNumber = User.Claims.FirstOrDefault(c => c.Type == "IdentificationNumber")?.Value;

            if (string.IsNullOrWhiteSpace(identificationNumber))
                return Unauthorized();

            var agent = await _agentService.GetAgentByIdAsync(identificationNumber);

            if (agent == null)
                return NotFound();

            return Ok(agent);
        }

        [Authorize(Roles = "Admin,Super Admin")]
        [HttpGet("admin-only")]
        public IActionResult AdminOnly()
        {
            return Ok(new { message = "Ovo vide samo admini." });
        }

        [Authorize]
        [HttpGet("check-id/{id}")]
        public async Task<IActionResult> CheckIfIDExistsAsync(string id)
        {
            var exists = await _agentService.CheckIfIdNumberExistsAsync(id);
            return Ok(exists);
        }

        [Authorize(Roles = "Admin,Super Admin")]
        [HttpGet("check-admin/{id}")]
        public async Task<IActionResult> CheckIfUserIsAdminAsync(string id)
        {
            var isAdmin = await _agentService.CheckIfUserIsAdminAsync(id);
            return Ok(isAdmin);
        }
    }
}