using Microsoft.AspNetCore.Mvc;
using Alpha.Repository.Common;

namespace Alpha.WebAPI.Controllers
{
    [Route("api/Clients")]
    [ApiController]
    public class ClientsController : ControllerBase
    {
        private readonly IClientRepository _clientRepository;

        public ClientsController(IClientRepository clientRepository)
        {
            _clientRepository = clientRepository;
        }

        [HttpGet("get-id-by-oib/{oib}")]
        public async Task<IActionResult> GetIdByOib(string oib)
        {
            var id = await _clientRepository.GetClientIdByOibAsync(oib);

            if (id == Guid.Empty)
                return NotFound("Klijent s tim OIB-om nije pronađen.");

            return Ok(new { clientId = id });
        }
    }
}